/*:
 ## Hello, it's not ending 😆
 
 In this playground we are going to play with **Solid of revolution** 🧐
 
 - Note:
 In mathematics, engineering, and manufacturing, a solid of revolution is a solid figure obtained by rotating a plane curve around some straight line (the axis of revolution) that lies on the same plane.
 \
 \
 Wikipedia
 
 
 ![Solidofrevolution](Solidofrevolution.png)
 
 ### Have Fun
 
 **Tips:** Using difference plane curve and rotating, see how a geometry is generated.
 
 **Enjoy and Learn** 👍👍👍
 
 */
